# Translator
LTL Logical equivalence generator and filter - inc. website and command line interface.
Designed for use in a GR(1) context in Spectra, but applications more generally too.